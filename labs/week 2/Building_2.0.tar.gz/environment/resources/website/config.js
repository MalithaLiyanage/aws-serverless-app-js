var G_API_GW_URL_STR = "https://ghh711iid6.execute-api.us-west-2.amazonaws.com/test";
var G_COGNITO_HOSTED_URL_STR = null;